# Software validation
Synthetic smoke test passed on 11 November 2026: all 9 model/feature pipelines trained;
27 diagnostic model-period rows produced; chronological partitions stayed separate;
unseen test category and missing training value handled; top-budget counts and score ties
checked; metric arithmetic checked; CSV/JSON exports and 3 plots generated.
Notebook format and Python syntax checked. This does not test the UCI download or establish
actual UCI performance. Real-data end-to-end run remains pending because DNS/download failed.
Synthetic fixtures/results are excluded from this deliverable. No real-data metrics are claimed.

## Official-data validation completed subsequently
Official-data primary experiment and pre-specified duplicate sensitivity both completed.
Verified 12,330 rows, 1,908 purchases, 4,725 unique held-out row IDs, and month boundaries.
Recomputed frozen-cutoff selection counts, buyer counts, precision, budget, and predicted
buyer totals independently from exported probabilities for November and December.
Inspected charts and checked notebook syntax/format. Synthetic results remain excluded.
